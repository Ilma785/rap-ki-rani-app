
# Rap Ki Rani Web App

This is a simple Spotify auth starter for the Rap Ki Rani playlist curation.

## Features
- Spotify login (authorization URL)
- Ready to deploy on Vercel

Replace `YOUR_CLIENT_ID` and `YOUR_REDIRECT_URI` in `index.html` before deploying.
    